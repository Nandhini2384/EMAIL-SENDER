const nodemailer = require('nodemailer');
const express = require('express');
const app = express();
const parser= require('body-parser');
const bodyParser = require('body-parser');



app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended:true}));
let transporter=nodemailer.createTransport({
    service:'gmail',
    auth:{
        user:'nandinandhini507@gmail.com',
        pass:'xbwk fszf fuza dvhn'
    }
});


app.get('/',(req,res)=>{
    res.sendFile(__dirname+'/public/hello.html')
});
app.post('/email',(req,res)=>{
    var emaList = req.body.emailid;
    console.log(emaList);
    var msg = req.body.msg;
  

    let mailOptions={
        from:'nandinandhini507@gmail.com',
        to: emaList,
        subject:'test email',
        text: msg,
        attachments: [{
            filename: 'demo.txt', // Name of the attachment
            path: '\demo.txt' // Path to the uploaded PDF file
        }]
    };
    
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error occurred:', error.message);
            res.status(500).send('Error occurred while sending email.');
        } else {
            console.log('Email sent:', info.response);
            res.send(`Email sent  to ${emaList} successfully!`);
        }
    });
});
app.listen(3000,()=>{
    console.log('server connected');
})